package combat.logic.statuseffect;

import combat.entity.Combatant.Combatant;
import combat.entity.Combatant.Player.Wizard;

public class ArcaneBlastBuff implements StatusEffect {
    @Override
    public void apply(Combatant target) {
        if (target instanceof Wizard) {
            ((Wizard) target).increaseArcaneBlastBonus();
        }
    }

    @Override
    public void remove(Combatant target) {
        // Permanent until level end, so remove is empty
    }

    @Override
    public void onTurnStart(Combatant target) {
        // Does not expire based on turns
    }

    @Override
    public boolean isExpired() {
        return false; // Stays active
    }

    @Override
    public String getName() { return "Arcane Power"; }
}