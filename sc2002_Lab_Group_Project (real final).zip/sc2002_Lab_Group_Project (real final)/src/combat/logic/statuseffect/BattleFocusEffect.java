package combat.logic.statuseffect;

import combat.entity.Combatant.Combatant;

public class BattleFocusEffect implements StatusEffect {
    private static final int ATTACK_BONUS = 15;
    private int duration = 3
    		;

    @Override
    public void apply(Combatant target) {
        target.addTemporaryAttackBonus(ATTACK_BONUS);
    }

    @Override
    public void remove(Combatant target) {
        target.removeTemporaryAttackBonus(ATTACK_BONUS);
    }

    @Override
    public void onTurnStart(Combatant target) {
        duration--;
    }

    @Override
    public boolean isExpired() {
        return duration <= 0;
    }

    @Override
    public String getName() {
        return "Battle Focus";
    }
}