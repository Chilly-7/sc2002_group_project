package combat.logic.statuseffect;

import combat.entity.Combatant.Combatant;

import combat.model.BattleLog;
public class StunEffect implements StatusEffect {
    private int turnsToSkip;

    public StunEffect(int turnsToSkip) {
        this.turnsToSkip = turnsToSkip;
    }

    @Override
    public void apply(Combatant target) {
        BattleLog.log(target.getName() + " is stunned!");
    }

    @Override
    public void remove(Combatant target) {
        BattleLog.log(target.getName() + " recovered from the stun.");
    }

    @Override
    public void onTurnStart(Combatant target) {
        turnsToSkip--;
    }

    @Override
    public boolean isExpired() {
        return turnsToSkip <= 0;
    }

    @Override
    public String getName() { return "Stunned"; }
}