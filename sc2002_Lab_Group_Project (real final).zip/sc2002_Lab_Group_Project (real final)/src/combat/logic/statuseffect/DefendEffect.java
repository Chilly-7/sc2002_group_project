package combat.logic.statuseffect;

import combat.entity.Combatant.Combatant;

public class DefendEffect implements StatusEffect {
    private int duration = 2;

    @Override
    public void apply(Combatant target) {
        target.addTemporaryDefenseBonus(10);
    }

    @Override
    public void onTurnStart(Combatant target) {
        duration--;
    }

    @Override
    public boolean isExpired() {
        return duration <= 0;
    }

    @Override
    public void remove(Combatant target) {
        target.removeTemporaryDefenseBonus(10);
    }

    @Override
    public String getName() {
        return "Defend";
    }
}