package combat.logic.statuseffect;

import combat.entity.Combatant.Combatant;
import combat.model.BattleLog;
public class SmokeBombEffect implements StatusEffect {
    private int duration;

    public SmokeBombEffect(int duration) {
        this.duration = duration;
    }

    @Override
    public void apply(Combatant target) {
        // While this is active, the BattleEngine or Combatant logic 
        // should check this effect to reduce damage to 0.
        BattleLog.log(target.getName() + " is hidden by a Smoke Bomb!");
    }

    @Override
    public void remove(Combatant target) {
        BattleLog.log("The smoke clears around " + target.getName() + ".");
    }

    @Override
    public void onTurnStart(Combatant target) {
        duration--;
    }

    @Override
    public boolean isExpired() {
        return duration <= 0;
    }

    @Override
    public String getName() {
        return "Smoke Bomb Evasion";
    }
}