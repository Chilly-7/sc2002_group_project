package combat.logic.statuseffect;

import combat.entity.Combatant.Combatant;

public interface StatusEffect {
    void apply(Combatant target);
    void remove(Combatant target);
    void onTurnStart(Combatant target); // Logic to run at the start of a turn
    boolean isExpired();
    String getName();
}