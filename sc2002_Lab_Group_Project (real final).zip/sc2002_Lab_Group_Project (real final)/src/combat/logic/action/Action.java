package combat.logic.action;

import combat.model.BattleContext;

public interface Action {
    void execute(BattleContext context);
    String getDescription();
}