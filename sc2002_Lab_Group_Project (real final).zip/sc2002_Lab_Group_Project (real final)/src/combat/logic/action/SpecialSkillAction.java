package combat.logic.action;

import combat.entity.Combatant.Enemy.Enemy;
import combat.entity.Combatant.Player.Player;
import combat.model.BattleContext;

public class SpecialSkillAction implements Action {
    private final Player player;
    private final Enemy target;
    private final boolean affectCooldown;

    public SpecialSkillAction(Player player, Enemy target) {
        this(player, target, true);
    }

    public SpecialSkillAction(Player player, Enemy target, boolean affectCooldown) {
        this.player = player;
        this.target = target;
        this.affectCooldown = affectCooldown;
    }

    @Override
    public void execute(BattleContext context) {
        player.useSpecialSkill(target, context, affectCooldown);
    }

    @Override
    public String getDescription() {
        return player.getName() + " unleashes " + player.getSpecialSkill().getName() + "!";
    }
}
