package combat.logic.action;

import combat.entity.Combatant.Combatant;
import combat.logic.statuseffect.DefendEffect;
import combat.model.BattleContext;
public class DefendAction implements Action {
    private final Combatant user;

    public DefendAction(Combatant user) {
        this.user = user;
    }

    @Override
    public void execute(BattleContext context) {
        context.getPlayer().addEffect(new DefendEffect());
    }

    @Override
    public String getDescription() {
        return user.getName() + " takes a defensive stance!";
    }
}