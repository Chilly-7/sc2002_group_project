package combat.logic.action;

import combat.model.BattleContext;
import combat.entity.Combatant.Player.Player;
import combat.logic.item.Item; // Assuming Item interface exists


public class UseItemAction implements Action {
    private final Player player;
    private final Item item;

    public UseItemAction(Player player, Item item) {
        this.player = player;
        this.item = item;
    }

    @Override
    public void execute(BattleContext context) {
        if (player.getInventory().contains(item)) {
            item.use(player, context);
            player.getInventory().remove(item);
        }
    }

    @Override
    public String getDescription() {
        return player.getName() + " uses " + item.getName() + "!";
    }
}