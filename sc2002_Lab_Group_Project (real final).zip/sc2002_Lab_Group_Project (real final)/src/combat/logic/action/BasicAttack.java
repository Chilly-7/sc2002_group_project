package combat.logic.action;

import combat.entity.Combatant.Combatant;
import combat.model.BattleContext;

import combat.model.BattleLog;
public class BasicAttack implements Action {
    private final Combatant attacker;
    private final Combatant target;

    public BasicAttack(Combatant attacker, Combatant target) {
        this.attacker = attacker;
        this.target = target;
    }

    @Override
    public void execute(BattleContext context) {
        if (target == null || !target.isAlive()) {
            BattleLog.log("No valid target selected.");
            return;
        }

        int damage = attacker.getAttack();
        int dealt = target.takeDamage(damage);
        BattleLog.log("Damage dealt: " + dealt);
    }

    @Override
    public String getDescription() {
        return attacker.getName() + " performs a Basic Attack on " + target.getName();
    }
}