package combat.logic.item;

import combat.entity.Combatant.Player.Player;
import combat.logic.statuseffect.BattleFocusEffect;
import combat.model.BattleContext;
import combat.model.BattleLog;

public class BattleElixir implements Item {
    @Override
    public void use(Player user, BattleContext context) {
        BattleLog.log(user.getName() + " drinks a Battle Elixir and feels empowered!");
        user.addEffect(new BattleFocusEffect());
}

    @Override
    public String getName() {
        return "Battle Elixir";
    }

    @Override
    public String getDescription() {
        return "Grants Battle Focus: +15 ATK for 2 turns.";
    }
}