package combat.logic.item;

import combat.entity.Combatant.Player.Player;
import combat.model.BattleContext;

import combat.model.BattleLog;
public class Potion implements Item {
    private static final int HEAL_AMOUNT = 100;

    @Override
    public void use(Player user, BattleContext context) {
        user.heal(HEAL_AMOUNT);
        BattleLog.log(user.getName() + " restores " + HEAL_AMOUNT + " HP.");
    }

    @Override
    public String getName() {
        return "Potion";
    }

    @Override
    public String getDescription() {
        return "Restores 100 HP.";
    }
}