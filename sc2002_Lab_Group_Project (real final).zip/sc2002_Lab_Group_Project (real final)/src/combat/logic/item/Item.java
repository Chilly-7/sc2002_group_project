package combat.logic.item;

import combat.entity.Combatant.Player.Player;
import combat.model.BattleContext;

public interface Item {
    void use(Player user, BattleContext context);
    String getName();
    String getDescription();
}
