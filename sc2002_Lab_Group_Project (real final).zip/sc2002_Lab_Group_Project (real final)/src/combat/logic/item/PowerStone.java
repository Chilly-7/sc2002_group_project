package combat.logic.item;

import combat.entity.Combatant.Enemy.Enemy;
import combat.entity.Combatant.Player.Player;
import combat.logic.action.SpecialSkillAction;
import combat.model.BattleContext;

import combat.model.BattleLog;
public class PowerStone implements Item {
    @Override
    public void use(Player user, BattleContext context) {
        Enemy target = null;
        if (user.getSpecialSkill().requiresTarget()) {
            target = context.getSelectedTarget();
        }

        BattleLog.log(user.getName() + " uses Power Stone to trigger " + user.getSpecialSkill().getName() + "!");
        new SpecialSkillAction(user, target, false).execute(context);
        BattleLog.log("Cooldown unchanged: " + user.getSpecialSkillCooldown());
    }

    @Override
    public String getName() {
        return "Power Stone";
    }

    @Override
    public String getDescription() {
        return "Triggers your special skill effect once without changing its cooldown.";
    }
}