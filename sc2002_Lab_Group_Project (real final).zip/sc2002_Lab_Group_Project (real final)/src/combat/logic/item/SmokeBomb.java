package combat.logic.item;

import combat.entity.Combatant.Player.Player;
import combat.logic.statuseffect.SmokeBombEffect;
import combat.model.BattleContext;

public class SmokeBomb implements Item {
    @Override
    public void use(Player user, BattleContext context) {
        user.addEffect(new SmokeBombEffect(2));
    }

    @Override
    public String getName() {
        return "Smoke Bomb";
    }

    @Override
    public String getDescription() {
        return "Enemy attacks do 0 damage this turn and the next turn.";
    }
}
