package combat.logic.specialskill;

import combat.entity.Combatant.Enemy.Enemy;
import combat.entity.Combatant.Player.Player;
import combat.model.BattleContext;

public interface SpecialSkill {
    void execute(Player user, Enemy target, BattleContext context);
    String getName();
    String getDescription();
    boolean requiresTarget();
}
