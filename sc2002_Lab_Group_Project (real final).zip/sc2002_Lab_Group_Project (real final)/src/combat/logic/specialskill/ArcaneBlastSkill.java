package combat.logic.specialskill;

import combat.entity.Combatant.Enemy.Enemy;
import combat.entity.Combatant.Player.Player;
import combat.entity.Combatant.Player.Wizard;
import combat.model.BattleContext;

import combat.model.BattleLog;
public class ArcaneBlastSkill implements SpecialSkill {
    @Override
    public void execute(Player user, Enemy target, BattleContext context) {
        if (!(user instanceof Wizard wizard)) {
            return;
        }

        for (Enemy enemy : context.getEnemies()) {
            if (!enemy.isAlive()) {
                continue;
            }

            int dealt = enemy.takeDamage(wizard.getAttack());
            BattleLog.log("Arcane Blast hits " + enemy.getName() + " for " + dealt + " damage!");

            if (!enemy.isAlive()) {
                wizard.increaseArcaneBlastBonus();
                BattleLog.log(enemy.getName() + " was defeated by Arcane Blast!");
                BattleLog.log("Wizard's attack increased by 10!");
            }
        }
    }

    @Override
    public String getName() {
        return "Arcane Blast";
    }

    @Override
    public String getDescription() {
        return "Deal BasicAttack damage to all living enemies. Each enemy defeated adds 10 Attack until end of level.";
    }

    @Override
    public boolean requiresTarget() {
        return false;
    }
}