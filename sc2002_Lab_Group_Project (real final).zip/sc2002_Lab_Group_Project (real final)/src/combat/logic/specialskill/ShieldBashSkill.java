package combat.logic.specialskill;

import combat.entity.Combatant.Enemy.Enemy;
import combat.entity.Combatant.Player.Player;
import combat.logic.statuseffect.StunEffect;
import combat.model.BattleContext;

import combat.model.BattleLog;
public class ShieldBashSkill implements SpecialSkill {
    @Override
    public void execute(Player user, Enemy target, BattleContext context) {
        if (target == null || !target.isAlive()) {
            BattleLog.log("No valid target selected for Shield Bash.");
            return;
        }

        int dealt = target.takeDamage(user.getAttack());
        BattleLog.log("Shield Bash hits " + target.getName() + " for " + dealt + " damage!");

        int turnsToSkip = context.selectedTargetActsLaterThisRound() ? 2 : 1;
        target.addEffect(new StunEffect(turnsToSkip));
    }

    @Override
    public String getName() {
        return "Shield Bash";
    }

    @Override
    public String getDescription() {
        return "Deal BasicAttack damage to one selected enemy and stun it for the current and next turn.";
    }

    @Override
    public boolean requiresTarget() {
        return true;
    }
}