package combat.entity.Combatant.Enemy;

import combat.entity.Combatant.Combatant;

import combat.model.BattleLog;
public abstract class Enemy extends Combatant {
    private boolean defeatAnnounced = false;

    public Enemy(String name, int hp, int attack, int defense, int speed) {
        super(name, hp, attack, defense, speed);
    }

    public void performBasicAttack(Combatant target) {
        int damage = this.getAttack();
        BattleLog.log(this.getName() + " attacks " + target.getName() + "!");
        int dealt = target.takeDamage(damage);
        BattleLog.log("Damage dealt: " + dealt);
    }

    public boolean isDefeatAnnounced() {
        return defeatAnnounced;
    }

    public void markDefeatAnnounced() {
        this.defeatAnnounced = true;
    }
}