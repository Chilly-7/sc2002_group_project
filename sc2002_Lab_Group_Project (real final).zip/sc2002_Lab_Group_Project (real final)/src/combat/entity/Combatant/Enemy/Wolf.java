package combat.entity.Combatant.Enemy;

public class Wolf extends Enemy {
    public Wolf(String id) {
        super("Wolf " + id, 40, 45, 5, 35);
    }
}
