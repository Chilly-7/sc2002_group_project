package combat.entity.Combatant.Player;

import combat.logic.specialskill.ArcaneBlastSkill;

public class Wizard extends Player {
    private int arcaneBlastBonus = 0;

    public Wizard() {
        super("Wizard", 200, 50, 10, 20, new ArcaneBlastSkill());
    }

    public void increaseArcaneBlastBonus() {
        this.arcaneBlastBonus += 10;
    }

    @Override
    public int getAttack() {
        return super.getAttack() + arcaneBlastBonus;
    }
}