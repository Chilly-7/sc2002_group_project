package combat.entity.Combatant.Player;

import combat.logic.specialskill.ShieldBashSkill;

public class Warrior extends Player {
    public Warrior() {
        super("Warrior", 260, 40, 20, 30, new ShieldBashSkill());
    }
}
