package combat.entity.Combatant.Player;

import combat.entity.Combatant.Combatant;
import combat.logic.item.Item;
import combat.logic.specialskill.SpecialSkill;
import combat.model.BattleContext;
import combat.entity.Combatant.Enemy.Enemy;

import java.util.ArrayList;
import java.util.List;

import combat.model.BattleLog;
public abstract class Player extends Combatant {
    protected int specialSkillCooldown = 0;
    protected static final int MAX_COOLDOWN = 3;
    protected List<Item> inventory;
    protected final SpecialSkill specialSkill;

    public Player(String name, int hp, int attack, int defense, int speed, SpecialSkill specialSkill) {
        super(name, hp, attack, defense, speed);
        this.inventory = new ArrayList<>();
        this.specialSkill = specialSkill;
    }

    public void decrementCooldown() {
        if (specialSkillCooldown > 0) {
            specialSkillCooldown--;
        }
    }

    public void putSpecialOnCooldown() {
        this.specialSkillCooldown = MAX_COOLDOWN;
    }

    public boolean isSpecialReady() {
        return specialSkillCooldown == 0;
    }

    public void useSpecialSkill(Enemy target, BattleContext context, boolean affectCooldown) {
        if (affectCooldown && !isSpecialReady()) {
            BattleLog.log("Special skill is on cooldown!");
            return;
        }

        specialSkill.execute(this, target, context);

        if (affectCooldown) {
            putSpecialOnCooldown();
        }
    }

    public List<Item> getInventory() { return inventory; }
    public int getSpecialSkillCooldown() { return specialSkillCooldown; }
    public SpecialSkill getSpecialSkill() { return specialSkill; }
}