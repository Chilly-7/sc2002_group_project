package combat.user_interface;

import java.util.List;

import combat.control.BattleObserver;
import combat.entity.Combatant.Enemy.Enemy;
import combat.entity.Combatant.Player.Player;

public class ConsoleBattleObserver implements BattleObserver {
    @Override
    public void showMessage(String message) {
        System.out.println(message);
    }

    @Override
    public void showCombatStart(Player player, List<Enemy> enemies) {
        System.out.println("\n=== COMBAT START! ===");
        System.out.println(player.getName() + " enters the arena!");
        System.out.println("Enemies:");
        for (Enemy enemy : enemies) {
            System.out.println("- " + enemy.getName()
                    + " | HP: " + enemy.getHp()
                    + " | ATK: " + enemy.getAttack()
                    + " | DEF: " + enemy.getDefense()
                    + " | SPD: " + enemy.getSpeed());
        }
        System.out.println();
    }

    @Override
    public void showRoundBanner(int roundCount) {
        System.out.println("\n=== ROUND " + roundCount + " ===");
    }

    @Override
    public void showCombatStatus(Player player, List<Enemy> enemies) {
        System.out.println("\n--- Combat Status ---");
        System.out.println(player.getName() + " | HP: " + player.getHp() + "/" + player.getMaxHp()
                + " | Cooldown: " + player.getSpecialSkillCooldown()
                + " | Status: " + (player.isAlive() ? "ALIVE" : "ELIMINATED"));
        for (Enemy enemy : enemies) {
            System.out.println(enemy.getName() + " | HP: " + enemy.getHp() + "/" + enemy.getMaxHp()
                    + " | Status: " + (enemy.isAlive() ? "ALIVE" : "ELIMINATED"));
        }
    }

    @Override
    public void showBackupWave(List<Enemy> enemies) {
        System.out.println("\n=== BACKUP WAVE ARRIVES! ===");
        for (Enemy enemy : enemies) {
            System.out.println("Reinforcement incoming: " + enemy.getName()
                    + " | HP: " + enemy.getHp()
                    + " | ATK: " + enemy.getAttack()
                    + " | DEF: " + enemy.getDefense()
                    + " | SPD: " + enemy.getSpeed());
        }
    }
}
