package combat.user_interface;

import combat.control.GameController;
import combat.entity.Combatant.Enemy.Enemy;
import combat.logic.item.Item;
import combat.model.BattleLog;
import combat.model.Difficulty;

import java.util.List;
import java.util.Scanner;

public class GameCLI {
    private final Scanner scanner;
    private GameController controller;

    public GameCLI() {
        this.scanner = new Scanner(System.in);
        ConsoleBattleObserver observer = new ConsoleBattleObserver();
        BattleLog.setSink(observer::showMessage);
        this.controller = new GameController(observer);
    }

    public void start() {
        boolean running = true;
        Integer lastHeroChoice = null;
        int[] lastItems = null;
        Difficulty lastDifficulty = null;

        while (running) {
            ConsoleBattleObserver observer = new ConsoleBattleObserver();
            BattleLog.setSink(observer::showMessage);
            this.controller = new GameController(observer);
            System.out.println("--- Welcome to the Turn-Based Combat Arena ---");

            if (lastHeroChoice == null || lastItems == null || lastDifficulty == null) {
                lastHeroChoice = promptHeroChoice();
                lastItems = promptItemChoices();
                lastDifficulty = promptDifficultyChoice();
            }

            controller.initializeGame(lastHeroChoice, lastItems, lastDifficulty);
            runGameLoop();
            displayEndScreen();

            int endChoice = promptEndMenuChoice();
            if (endChoice == 1) {
                continue;
            }
            if (endChoice == 2) {
                lastHeroChoice = null;
                lastItems = null;
                lastDifficulty = null;
                continue;
            }
            running = false;
        }

        System.out.println("Thanks for playing!");
    }

    private int promptHeroChoice() {
        System.out.println("\n=== Choose Your Hero ===");
        System.out.println("1) Warrior");
        System.out.println("   HP: 260 | ATK: 40 | DEF: 20 | SPD: 30");
        System.out.println("   Skill: Shield Bash - deals damage and stuns one selected enemy.");
        System.out.println();
        System.out.println("2) Wizard");
        System.out.println("   HP: 200 | ATK: 50 | DEF: 10 | SPD: 20");
        System.out.println("   Skill: Arcane Blast - damages all living enemies. Each kill adds 10 ATK until level end.");
        return readIntInRange("Enter choice: ", 1, 2);
    }

    private int[] promptItemChoices() {
        System.out.println("\n=== Select 2 Items ===");
        System.out.println("1) Potion        - Restores 100 HP.");
        System.out.println("2) Power Stone   - Triggers your special skill once without changing cooldown.");
        System.out.println("3) Smoke Bomb    - Enemy attacks do 0 damage this turn and next turn.");
        System.out.println("4) Battle Elixir - Grants Battle Focus: +15 ATK for 2 turns.");
        int item1 = readIntInRange("Choose item 1: ", 1, 4);
        int item2 = readIntInRange("Choose item 2: ", 1, 4);
        return new int[] { item1, item2 };
    }

    private Difficulty promptDifficultyChoice() {
        System.out.println("\n=== Select Difficulty ===");
        System.out.println("1) Easy");
        System.out.println("   Initial wave: 3 Goblins");
        System.out.println("   Backup wave : None");
        System.out.println();
        System.out.println("2) Medium");
        System.out.println("   Initial wave: 1 Goblin, 1 Wolf");
        System.out.println("   Backup wave : 2 Wolves");
        System.out.println();
        System.out.println("3) Hard");
        System.out.println("   Initial wave: 2 Goblins");
        System.out.println("   Backup wave : 1 Goblin, 2 Wolves");
        System.out.println();
        System.out.println("Enemy stats:");
        System.out.println("Goblin -> HP: 55 | ATK: 35 | DEF: 15 | SPD: 25");
        System.out.println("Wolf   -> HP: 40 | ATK: 45 | DEF: 5  | SPD: 35");
        int diffChoice = readIntInRange("Enter choice: ", 1, 3);
        return Difficulty.values()[diffChoice - 1];
    }

    private void runGameLoop() {
        while (!controller.isGameOver()) {
            if (controller.isPlayerTurn()) {
                displayPlayerMenu();
                int action = readIntInRange("Choose action: ", 1, 4);

                Integer targetChoice = null;
                Integer itemChoice = null;

                if (action == 1) {
                    targetChoice = promptTargetChoice();
                } else if (action == 3) {
                    itemChoice = promptItemUseChoice();
                    if (itemChoice != null) {
                        Item chosenItem = controller.getInventory().get(itemChoice - 1);
                        if (chosenItem.getName().equals("Power Stone") && controller.getPlayer().getSpecialSkill().requiresTarget()) {
                            targetChoice = promptTargetChoice();
                        }
                    }
                } else if (action == 4 && controller.getPlayer().getSpecialSkill().requiresTarget()) {
                    targetChoice = promptTargetChoice();
                }

                controller.handlePlayerAction(action, targetChoice, itemChoice);
            } else {
                controller.processEnemyTurns();
            }
        }
    }

    private void displayPlayerMenu() {
        System.out.println("\n--- Your Turn ---");
        System.out.println("1) Basic Attack");
        System.out.println("2) Defend");
        System.out.println("3) Use Item");
        System.out.println("4) Special Skill");
    }

    private Integer promptTargetChoice() {
        List<Enemy> aliveEnemies = controller.getAliveEnemies();
        if (aliveEnemies.isEmpty()) {
            System.out.println("No enemies available to target.");
            return null;
        }

        System.out.println("\nChoose target:");
        for (int i = 0; i < aliveEnemies.size(); i++) {
            Enemy enemy = aliveEnemies.get(i);
            System.out.printf("%d) %s | HP: %d | ATK: %d | DEF: %d | SPD: %d%n",
                    i + 1, enemy.getName(), enemy.getHp(), enemy.getAttack(), enemy.getDefense(), enemy.getSpeed());
        }
        return readIntInRange("Enter target: ", 1, aliveEnemies.size());
    }

    private Integer promptItemUseChoice() {
        List<Item> inventory = controller.getInventory();
        if (inventory.isEmpty()) {
            System.out.println("Inventory empty!");
            return null;
        }

        System.out.println("\nChoose item:");
        for (int i = 0; i < inventory.size(); i++) {
            Item item = inventory.get(i);
            System.out.printf("%d) %s - %s%n", i + 1, item.getName(), item.getDescription());
        }
        return readIntInRange("Enter item: ", 1, inventory.size());
    }

    private void displayEndScreen() {
        if (controller.didPlayerWin()) {
            CombatPrinter.printVictory(controller.getBattleStats());
        } else {
            CombatPrinter.printDefeat(controller.getBattleStats());
        }
    }

    private int promptEndMenuChoice() {
        System.out.println("1) Replay with the same settings");
        System.out.println("2) Start a new game");
        System.out.println("3) Exit");
        return readIntInRange("Enter choice: ", 1, 3);
    }

    private int readIntInRange(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            if (!scanner.hasNextLine()) {
                System.out.println("\nNo more input detected. Exiting game.");
                System.exit(0);
            }
            String input = scanner.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.println("Please enter a number from " + min + " to " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a whole number.");
            }
        }
    }

    public static void main(String[] args) {
        GameCLI game = new GameCLI();
        game.start();
    }
}
