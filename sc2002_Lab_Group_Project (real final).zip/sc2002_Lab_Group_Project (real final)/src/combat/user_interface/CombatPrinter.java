// utility class that prevents BattleEngine from being cluttered with System.out.println statements
// SRP*


package combat.user_interface;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import combat.logic.statuseffect.StatusEffect;

public class CombatPrinter {

	public void printBattleState(String name, int hp, int maxHp, int cooldown, List<StatusEffect> effects) {
	    String effectStr = effects.isEmpty() ? "None" 
	        : effects.stream().map(StatusEffect::getName).collect(Collectors.joining(", "));
	    System.out.printf("[%s] HP: %d/%d | Special Cooldown: %d rounds | Effects: [%s]%n",
	        name, hp, maxHp, cooldown, effectStr);
	}

    public static void printAction(String attacker, String action, String target, int damage) {
        System.out.printf("%s performs %s on %s! Damage dealt: %d\n", 
                          attacker, action, target, damage); 
    }

    public static void printVictory(Map<String, Integer> stats) {
        System.out.println("\n========================================");
        System.out.println("Congratulations, you have defeated all your enemies."); 
        System.out.println("Remaining HP: " + stats.get("hp")); 
        System.out.println("Total Rounds: " + stats.get("rounds")); 
        System.out.println("========================================\n");
    }

    public static void printDefeat(Map<String, Integer> stats) {
        System.out.println("\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx");
        System.out.println("Defeated. Don't give up, try again!"); 
        System.out.println("Enemies remaining: " + stats.get("enemiesLeft")); 
        System.out.println("Total Rounds Survived: " + stats.get("rounds")); 
        System.out.println("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n");
    }
    
    public static void printStatusApplied(String entity, String effect) {
        System.out.println(">>> " + entity + " is now affected by " + effect + "!"); 
    }
}
