package combat;

import combat.user_interface.GameCLI;

public class Main {
    public static void main(String[] args) {
        GameCLI.main(args);
    }
}
