// This implements the specific rule: "Higher speed goes first."

package combat.control;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import combat.entity.Combatant.Combatant;

public class SpeedBasedTurnStrategy implements TurnOrderStrategy {
    @Override
    public List<Combatant> determineOrder(List<Combatant> allCombatants) {
        // Create a copy to avoid modifying the original list directly
        return allCombatants.stream()
            .filter(Combatant::isAlive)
            .sorted(Comparator.comparingInt(Combatant::getSpeed).reversed())
            .collect(Collectors.toList());
    }
}