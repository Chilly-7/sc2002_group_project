package combat.control;

import combat.entity.Combatant.Enemy.Enemy;
import combat.entity.Combatant.Player.Player;
import combat.logic.item.Item;
import combat.model.Difficulty;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameController {
    private final BattleObserver observer;
    private Player player;
    private BattleEngine battleEngine;
    private boolean playerWin = false;

    public GameController(BattleObserver observer) {
        this.observer = observer;
    }

    public void initializeGame(int heroType, int[] itemIds, Difficulty difficulty) {
        this.player = LevelFactory.createPlayer(heroType, itemIds);
        this.battleEngine = new BattleEngine(player, LevelFactory.createInitialEnemies(difficulty), difficulty, observer);
    }

    public boolean isPlayerTurn() {
        return battleEngine.getCurrentTurnOwner() instanceof Player;
    }

    public void handlePlayerAction(int actionChoice, Integer targetChoice, Integer itemChoice) {
        battleEngine.executePlayerTurn(actionChoice, targetChoice, itemChoice);
    }

    public void processEnemyTurns() {
        battleEngine.executeEnemyTurns();
    }

    public boolean isGameOver() {
        if (player.getHp() <= 0) return true;
        if (battleEngine.allEnemiesDefeated()) {
            playerWin = true;
            return true;
        }
        return false;
    }

    public boolean didPlayerWin() {
        return playerWin;
    }

    public Map<String, Integer> getBattleStats() {
        Map<String, Integer> stats = new HashMap<>();
        stats.put("hp", player.getHp());
        stats.put("rounds", battleEngine.getRoundCount());
        stats.put("enemiesLeft", battleEngine.getRemainingEnemyCount());
        return stats;
    }

    public List<Enemy> getAliveEnemies() {
        return battleEngine.getAliveEnemies();
    }

    public List<Item> getInventory() {
        return player.getInventory();
    }

    public Player getPlayer() {
        return player;
    }
}
