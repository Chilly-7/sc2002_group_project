// The TurnManager maintains the state of the current round. 
// It keeps track of whose turn it is and knows when a round has ended.

package combat.control;

import combat.entity.Combatant.Combatant;
import combat.entity.Combatant.Enemy.Enemy;
import combat.entity.Combatant.Player.Player;

import java.util.ArrayList;
import java.util.List;

public class TurnManager {
    private List<Combatant> turnOrder;
    private int currentIndex;
    private TurnOrderStrategy strategy;

    public TurnManager() {
        this.strategy = new SpeedBasedTurnStrategy();
        this.turnOrder = new ArrayList<>();
        this.currentIndex = 0;
    }

    public void generateOrder(Player player, List<Enemy> enemies) {
        List<Combatant> all = new ArrayList<>();
        all.add(player);
        all.addAll(enemies);
        
        this.turnOrder = strategy.determineOrder(all);
        this.currentIndex = 0; // Reset to start of the list for the new round
    }

    public Combatant getCurrent() {
        if (currentIndex < turnOrder.size()) {
            return turnOrder.get(currentIndex);
        }
        return null;
    }

    public void nextTurn() {
        currentIndex++;
    }

    public boolean isRoundComplete() {
        return currentIndex >= turnOrder.size();
    }

    public boolean hasUpcomingTurn(Combatant target) {
        if (target == null) {
            return false;
        }
        for (int i = currentIndex + 1; i < turnOrder.size(); i++) {
            if (turnOrder.get(i) == target) {
                return true;
            }
        }
        return false;
    }

    // Allows switching strategy at runtime (Bonus for OCP/DIP)
    public void setStrategy(TurnOrderStrategy strategy) {
        this.strategy = strategy;
    }
}