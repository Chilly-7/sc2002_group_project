package combat.control;

import combat.entity.Combatant.Combatant;
import combat.entity.Combatant.Enemy.Enemy;
import combat.entity.Combatant.Player.Player;
import combat.logic.action.Action;
import combat.logic.action.BasicAttack;
import combat.logic.action.DefendAction;
import combat.logic.action.SpecialSkillAction;
import combat.logic.action.UseItemAction;
import combat.logic.item.Item;
import combat.logic.statuseffect.StunEffect;
import combat.model.BattleContext;
import combat.model.Difficulty;

import java.util.List;
import java.util.stream.Collectors;

public class BattleEngine {
    private final Player player;
    private final List<Enemy> enemies;
    private final TurnManager turnManager;
    private final Difficulty difficulty;
    private final BattleObserver observer;
    private int roundCount = 1;
    private boolean backupSpawned = false;

    public BattleEngine(Player player, List<Enemy> enemies, Difficulty difficulty, BattleObserver observer) {
        this.player = player;
        this.enemies = enemies;
        this.difficulty = difficulty;
        this.observer = observer;
        this.turnManager = new TurnManager();
        refreshTurnOrder();

        observer.showCombatStart(player, enemies);
        observer.showRoundBanner(roundCount);
    }

    public void executePlayerTurn(int choice, Integer targetChoice, Integer itemChoice) {
        Combatant current = turnManager.getCurrent();
        if (!(current instanceof Player)) {
            return;
        }

        Player activePlayer = (Player) current;

        if (!activePlayer.isAlive()) {
            return;
        }

        boolean isStunned = activePlayer.hasEffect(StunEffect.class);
        if (isStunned) {
            activePlayer.decrementCooldown();
            observer.showMessage(activePlayer.getName() + " is stunned and skips their turn!");
            activePlayer.processStatusEffects();
            finishTurn();
            return;
        }

        BattleContext context = new BattleContext(activePlayer, enemies);
        Enemy chosenTarget = getAliveEnemyByChoice(targetChoice);
        context.setSelectedTarget(chosenTarget);
        context.setSelectedTargetActsLaterThisRound(turnManager.hasUpcomingTurn(chosenTarget));
        Action action = null;

        switch (choice) {
            case 1:
                if (chosenTarget != null) {
                    action = new BasicAttack(activePlayer, chosenTarget);
                } else {
                    observer.showMessage("Invalid target.");
                    return;
                }
                break;
            case 2:
                action = new DefendAction(activePlayer);
                break;
            case 3:
                Item item = getItemByChoice(itemChoice);
                if (item != null) {
                    action = new UseItemAction(activePlayer, item);
                } else {
                    observer.showMessage("Invalid item choice.");
                    return;
                }
                break;
            case 4:
                if (activePlayer.isSpecialReady()) {
                    if (activePlayer.getSpecialSkill().requiresTarget() && chosenTarget == null) {
                        observer.showMessage("Invalid target.");
                        return;
                    } else {
                        action = new SpecialSkillAction(activePlayer, chosenTarget);
                    }
                } else {
                    observer.showMessage("Special skill is on cooldown!");
                    return;
                }
                break;
            default:
                observer.showMessage("Invalid action.");
                return;
        }

        if (action != null) {
            activePlayer.decrementCooldown();
            activePlayer.processStatusEffects();
            observer.showMessage(action.getDescription());
            action.execute(context);
            handleDefeatedEnemies();
        }

        finishTurn();
    }

    public void executeEnemyTurns() {
        while (!allEnemiesDefeated()) {
            Combatant current = turnManager.getCurrent();

            if (current == null) {
                refreshTurnOrder();
                current = turnManager.getCurrent();
                if (current == null) {
                    return;
                }
            }

            if (current instanceof Player) {
                return;
            }

            if (current.isAlive()) {
                boolean isStunned = current.hasEffect(StunEffect.class);

                if (!isStunned) {
                    current.processStatusEffects();
                    ((Enemy) current).performBasicAttack(player);
                } else {
                    observer.showMessage(current.getName() + " is stunned and skips their turn!");
                    current.processStatusEffects();
                }
            }

            finishTurn();
            if (!player.isAlive()) {
                return;
            }
        }
    }

    private Enemy getAliveEnemyByChoice(Integer targetChoice) {
        List<Enemy> aliveEnemies = getAliveEnemies();
        if (aliveEnemies.isEmpty()) {
            return null;
        }
        if (targetChoice == null || targetChoice < 1 || targetChoice > aliveEnemies.size()) {
            return null;
        }
        return aliveEnemies.get(targetChoice - 1);
    }

    private Item getItemByChoice(Integer itemChoice) {
        if (itemChoice == null || itemChoice < 1 || itemChoice > player.getInventory().size()) {
            return null;
        }
        return player.getInventory().get(itemChoice - 1);
    }

    private void handleDefeatedEnemies() {
        for (Enemy enemy : enemies) {
            if (!enemy.isAlive() && !enemy.isDefeatAnnounced()) {
                observer.showMessage(enemy.getName() + " has been defeated!");
                enemy.markDefeatAnnounced();
            }
        }
    }

    private boolean checkAndSpawnBackup() {
        if (!backupSpawned && enemies.stream().noneMatch(Combatant::isAlive)) {
            List<Enemy> backup = LevelFactory.createBackupEnemies(difficulty);
            if (!backup.isEmpty()) {
                observer.showBackupWave(backup);
                enemies.addAll(backup);
                backupSpawned = true;
                refreshTurnOrder();
                return true;
            }
        }
        return false;
    }

    private void finishTurn() {
        turnManager.nextTurn();

        boolean battleEnded = !player.isAlive() || allEnemiesDefeated();
        boolean roundComplete = turnManager.isRoundComplete();

        if (battleEnded || roundComplete) {
            observer.showCombatStatus(player, enemies);
        }

        if (battleEnded) {
            return;
        }

        if (roundComplete) {
            roundCount++;
            if (!checkAndSpawnBackup()) {
                refreshTurnOrder();
            }
            if (!player.isAlive() || allEnemiesDefeated()) {
                return;
            }
            observer.showRoundBanner(roundCount);
        }
    }

    private void refreshTurnOrder() {
        turnManager.generateOrder(player, enemies);
    }

    public Combatant getCurrentTurnOwner() {
        return turnManager.getCurrent();
    }

    public boolean allEnemiesDefeated() {
        return enemies.stream().noneMatch(Combatant::isAlive) && (backupSpawned || difficulty == Difficulty.EASY);
    }

    public int getRoundCount() {
        return roundCount;
    }

    public int getRemainingEnemyCount() {
        return (int) enemies.stream().filter(Combatant::isAlive).count();
    }

    public List<Enemy> getAliveEnemies() {
        return enemies.stream().filter(Combatant::isAlive).collect(Collectors.toList());
    }
}
