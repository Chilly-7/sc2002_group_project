package combat.control;

import java.util.List;

import combat.entity.Combatant.Enemy.Enemy;
import combat.entity.Combatant.Player.Player;

public interface BattleObserver {
    void showMessage(String message);
    void showCombatStart(Player player, List<Enemy> enemies);
    void showRoundBanner(int roundCount);
    void showCombatStatus(Player player, List<Enemy> enemies);
    void showBackupWave(List<Enemy> enemies);
}
