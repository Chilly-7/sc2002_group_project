package combat.control;

import combat.logic.item.*;
import combat.entity.Combatant.Enemy.*;
import combat.entity.Combatant.Player.*;
import combat.model.Difficulty;

import java.util.ArrayList;
import java.util.List;

public class LevelFactory {

    public static Player createPlayer(int heroType, int[] itemIds) {
        Player player = (heroType == 1) ? new Warrior() : new Wizard();

        for (int id : itemIds) {
            Item item = createItem(id);
            if (item != null) {
                player.getInventory().add(item);
            }
        }
        return player;
    }

    public static Item createItem(int itemId) {
        switch (itemId) {
            case 1:
                return new Potion();
            case 2:
                return new PowerStone();
            case 3:
                return new SmokeBomb();
            case 4:
                return new BattleElixir();
            default:
                return null;
        }
    }

    public static List<Enemy> createInitialEnemies(Difficulty difficulty) {
        List<Enemy> enemies = new ArrayList<>();

        switch (difficulty) {
            case EASY:
                enemies.add(new Goblin("A"));
                enemies.add(new Goblin("B"));
                enemies.add(new Goblin("C"));
                break;
            case MEDIUM:
                enemies.add(new Goblin("A"));
                enemies.add(new Wolf("A"));
                break;
            case HARD:
                enemies.add(new Goblin("A"));
                enemies.add(new Goblin("B"));
                break;
            default:
                break;
        }
        return enemies;
    }

    public static List<Enemy> createBackupEnemies(Difficulty difficulty) {
        List<Enemy> backup = new ArrayList<>();

        if (difficulty == Difficulty.MEDIUM) {
            backup.add(new Wolf("B"));
            backup.add(new Wolf("C"));
        } else if (difficulty == Difficulty.HARD) {
            backup.add(new Goblin("C"));
            backup.add(new Wolf("A"));
            backup.add(new Wolf("B"));
        }

        return backup;
    }
}
