// Abstraction. 
// Any class that implements this must be able to take a list of combatants and return them in a sorted order.

package combat.control;

import java.util.List;

import combat.entity.Combatant.Combatant;

public interface TurnOrderStrategy {
    List<Combatant> determineOrder(List<Combatant> allCombatants);
}