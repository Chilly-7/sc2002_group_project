package combat.model;

public enum Difficulty {
    EASY,
    MEDIUM,
    HARD
}