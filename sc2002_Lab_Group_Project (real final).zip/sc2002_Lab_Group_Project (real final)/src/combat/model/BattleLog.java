package combat.model;

import java.util.function.Consumer;

public final class BattleLog {
    private static Consumer<String> sink = message -> {};

    private BattleLog() {
    }

    public static void setSink(Consumer<String> sink) {
        BattleLog.sink = (sink == null) ? message -> {} : sink;
    }

    public static void log(String message) {
        sink.accept(message);
    }
}
