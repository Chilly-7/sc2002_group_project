package combat.model;

import combat.entity.Combatant.Player.Player;
import combat.entity.Combatant.Enemy.Enemy;
import java.util.List;

public class BattleContext {
    private final Player player;
    private final List<Enemy> enemies;
    private Enemy selectedTarget;
    private boolean selectedTargetActsLaterThisRound;

    public BattleContext(Player player, List<Enemy> enemies) {
        this.player = player;
        this.enemies = enemies;
    }

    public Player getPlayer() {
        return player;
    }

    public List<Enemy> getEnemies() {
        return enemies;
    }

    public Enemy getSelectedTarget() {
        return selectedTarget;
    }

    public void setSelectedTarget(Enemy selectedTarget) {
        this.selectedTarget = selectedTarget;
    }

    public boolean selectedTargetActsLaterThisRound() {
        return selectedTargetActsLaterThisRound;
    }

    public void setSelectedTargetActsLaterThisRound(boolean selectedTargetActsLaterThisRound) {
        this.selectedTargetActsLaterThisRound = selectedTargetActsLaterThisRound;
    }
}
