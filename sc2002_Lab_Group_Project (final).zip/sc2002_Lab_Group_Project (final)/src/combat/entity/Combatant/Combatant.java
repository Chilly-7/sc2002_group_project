package combat.entity.Combatant;

import combat.logic.statuseffect.SmokeBombEffect;
import combat.logic.statuseffect.StatusEffect;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import combat.model.BattleLog;
public abstract class Combatant {
    protected String name;
    protected int hp;
    protected int maxHp;
    protected int attack;
    protected int defense;
    protected int speed;
    protected boolean isDefending = false;
    protected List<StatusEffect> activeEffects;
    protected int temporaryDefenseBonus = 0;

    public Combatant(String name, int hp, int attack, int defense, int speed) {
        this.name = name;
        this.hp = hp;
        this.maxHp = hp;
        this.attack = attack;
        this.defense = defense;
        this.speed = speed;
        this.activeEffects = new ArrayList<>();
    }

    public void addTemporaryDefenseBonus(int amount) {
        temporaryDefenseBonus += amount;
    }

    public void removeTemporaryDefenseBonus(int amount) {
        temporaryDefenseBonus -= amount;
        if (temporaryDefenseBonus < 0) {
            temporaryDefenseBonus = 0;
        }
    }
    
    public int takeDamage(int rawDamage) {
        boolean isInvisible = activeEffects.stream().anyMatch(e -> e instanceof SmokeBombEffect);
        if (isInvisible) {
            BattleLog.log(this.name + " is hidden by a smoke bomb and takes no damage!");
            return 0;
        }

        int totalDefense = this.defense + this.temporaryDefenseBonus;
        int finalDamage = Math.max(0, rawDamage - totalDefense);
        this.hp = Math.max(0, this.hp - finalDamage);
        return finalDamage;
    }

    public void heal(int amount) {
        this.hp = Math.min(this.maxHp, this.hp + amount);
    }

    public boolean isAlive() {
        return this.hp > 0;
    }

    public void addEffect(StatusEffect effect) {
        boolean alreadyActive = activeEffects.stream()
                .anyMatch(e -> e.getClass().equals(effect.getClass()));

        if (alreadyActive) {
            return;
        }

        effect.apply(this);
        activeEffects.add(effect);
        BattleLog.log(this.name + " is affected by " + effect.getName() + "!");
    }
    
    public void processStatusEffects() {
        Iterator<StatusEffect> iterator = activeEffects.iterator();

        while (iterator.hasNext()) {
            StatusEffect effect = iterator.next();
            effect.onTurnStart(this);

            if (effect.isExpired()) {
                effect.remove(this);
                iterator.remove();
                BattleLog.log(this.name + " is no longer affected by " + effect.getName() + ".");
            }
        }
    }
    

    public boolean hasEffect(Class<? extends StatusEffect> effectClass) {
        return activeEffects.stream().anyMatch(effectClass::isInstance);
    }

    public String getName() { return name; }
    public int getHp() { return hp; }
    public int getMaxHp() { return maxHp; }
    public int getAttack() { return attack; }
    public int getDefense() { return defense; }
    public int getSpeed() { return speed; }
    public void setDefending(boolean defending) { this.isDefending = defending; }
    public List<StatusEffect> getActiveEffects() { return activeEffects; }
}